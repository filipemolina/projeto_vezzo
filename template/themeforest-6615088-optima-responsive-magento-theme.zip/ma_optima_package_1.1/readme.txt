
01/18/2014: Released version 1.0
	- You need read instruction: ma_optima_document.pdf
	- Download PSD source : http://www.plazathemes.com/demo/psd/ma_optima_source_8456354.zip
	
01/24/2013: Updated version 1.1
	- Fixed style for review form in the product page.
	- Fixed possition "This is a required field" in create new account page.

